# SUNNYapplication
SK SUNNY Social Innovative Project - SLOWERTHANNOW


_### **"SK SUNNY Social Innovative Project - SLOWERTHANNOW"**_

The modern alarm application which will give you a pleasant sleep without any disturbing SNS.
We are focusing on solving the social problem, the sleeping disorder problem caused by overusing of SNS at nighttime.
If you use this applicaiton, Facebook, Instagram, Twitter, Youtube, KakaoTalk will be locked down after the time you set to sleep. Until the next day 5:00 am.

We have several functions.

1. Alarm Notification before the time you set to sleep.
2. SNS Shut-down during the time you set to sleep.


We will soon implement more elaborated functions and clear UI/UX.

                                                                      - SK SUNNY SLOWERTHANNOW Team.
